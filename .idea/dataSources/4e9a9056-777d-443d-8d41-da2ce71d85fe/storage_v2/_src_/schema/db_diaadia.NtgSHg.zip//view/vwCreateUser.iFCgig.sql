create definer = user_test@localhost view vwCreateUser as
select `a`.`userId` AS `userId`, `u`.`name` AS `name`, `u`.`password` AS `password`, `a`.`key_value` AS `key_value`
from (`db_diaadia`.`apiKeys` `a` join `db_diaadia`.`tbUser` `u` on ((`a`.`userId` = `u`.`id`)));

